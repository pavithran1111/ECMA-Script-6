function createBookShop(inventory) {
  return {
    inventory,
    inventoryValue(){
      return this.inventory.reduce((total, book) => total + book.price, 0)
    },
    priceForTitle(title) {
			return this.inventory.find(book => book.title === title ).title;
    }
  }
}

const inventory = [
  {title: "Wings of Fire", price: 35},
  {title: "Fire", price: 60}
]

const bookShop = createBookShop(inventory);

bookShop.inventoryValue();
bookShop.priceForTitle('Wings of Fire');

// --------------------------------------------------

