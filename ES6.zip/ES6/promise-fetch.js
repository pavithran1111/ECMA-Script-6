promise = new Promise((resolve, reject)=>{
	resolve();
  reject();
});

promise
  .then(()=> console.log('finally finishes'))
  .then(()=> console.log('I was also ran!!!'))
  .catch(()=> console.log('uh ho!!'));

// -------------------------------------------------------

url = 'https://jsonplaceholder.typicode.com/posts/';

fetch(url)
  .then(response => response.json())
  .then(data => console.log(data));

// -------------------------------------------------------
  url1 = 'https://jsonplaceholder.typicode1.com/post12345/';

  fetch(url1)
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.log('BAD', error));