let f = [1,2,3,4,5]

let sum = 0;

const adder = number => {
  sum+=number
}
let a = f.forEach(adder)

sum