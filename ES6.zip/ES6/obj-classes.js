function Car(option) {
  this.title = option.title;
}

Car.prototype.drive = function() {
  return 'vroom';  
}

function Toyota(option) {
  Car.call(this, option)
  this.color = option.color;
}

Toyota.prototype = Object.create(Car.prototype);
Toyota.prototype.constructor = Toyota;


Toyota.prototype.honk = function (){
 return 'Beep'; 
}


const toyota = new Toyota({color: 'blue', title: 'driver'});

toyota;
toyota.drive();
toyota.honk();

// --------------------------------------------------------

class Car {
  constructor({title}){
    this.title = title;
  }
  drive(){
    return 'vroom';
  }
 }
 
 class Toyota extends Car {
 
   constructor(options){
    super(options);
    this.color = options.color;
  }
 
   honk(){
    return 'beep'; 
   }
 }
 
 const toyota1 = new Toyota({color: 'blue', title: 'Focus'});
 
 '----------';
 toyota1.honk();
 toyota1.drive();
 toyota1

//  -------------------------------------------------

class Monster {
  constructor(options) {
    this.health = 100;
    this.name = options.name;
  }
}

class Snake extends Monster{
    constructor(options){
        super(options);
    }
    bite(snake){
        return snake.health -= 10;
    }
}

const monster = new Monster({name: 'Buraot'});
const snake = new Snake({name: 'snake'});
snake.bite({health:100});
 


 
 

