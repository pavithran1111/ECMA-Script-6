const {type, amount} = {
  type: "Business",
 
 amount: "500"
 
}
type;
amount;

// ----------------------------------------

let savedFile = {
  extension: "png",
 fileName: "Check List",
 size: 1400
}

function fileSummary({fileName, extension, size }, {name}){
 
return `${name} The file ${fileName}.${extension} is of size ${size}`; 
}

fileSummary(savedFile, {name: 'Ram'})
// --------------------------------------------------------------------

// destructoring array

const [a, b, c] = ['google', 'facebook', 'uber'];
a;
b;
c;

const {length} = ['google', 'facebook', 'uber'];
length;

const [a1, ...length1] = ['google', 'facebook', 'uber'];
a;
length1;
// -----------------------------------------------------

const companies = [
  {name: "Google", location: "Mountain View"},
  {name: "Facebook", location: "Menlo Park"},
  {name: "Uber", location: "Down Town, SanFransico"}
]

const [{location}, name1 = { name }, ...rest] = [
  {name: "Google", location: "Mountain View"},
  {name: "Facebook", location: "Menlo Park"},
  {name: "Uber", location: "Down Town, SanFransico"}
]

location;
name1.name;

const {locations:[city1, ...other]} = {
 locations: ['New Delhi', 'Mumbai', 'Bangalore']
}

city1;
other

// ----------------------------------------------------------

function signup({phone, name}){
  return `${name} ${phone}`
  
}

const user = {
	name: 'myname',
  passowrd: 'mypassword',
  email: 'email',
  dob: 'dob',
  phone: 97978979889
}


signup(user);

// ----------------------------------------------------------

const points = [
  [4, 5],
  [10,1],
  [8,7]
];

points.map(([x, y]) => ({x, y}))

// ---------------------------------------------------

const numbers = [1, 2, 3];

function double(num) {
    return num.map(n => n*2)
}

double(numbers)

const numbers1 = [1, 2, 3];

function double1([...a]) {
    return [...a]
}

double1(numbers1)

