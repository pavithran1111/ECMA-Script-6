function userId(id){
  
  this.id= id 
 }
 
 //new userId(1)
 
 function generateUser(){
   
  return Math.random() * 565 
 }
 
 //generateUser()
 
 function createAdminUser(user = new userId(generateUser())){
   
   user.admin = true;
 
   return user;
 }
 const user = new userId(generateUser());
 createAdminUser();
 