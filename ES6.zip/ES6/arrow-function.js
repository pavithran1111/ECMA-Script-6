const teams = {
  members: ['Ram', 'Laxman'],
  teamName: "Squad",
  teamSummary: function(){
    return this.members.map(function(member){
      return `${member} is on team ${this.teamName}`
    }.bind(this))
  }
}

teams.teamSummary();

// -----------------------------------------------

const teams1 = {
  members: ['Ram', 'Laxman'],
  teamName: "Squad",
  teamSummary: function(){
    return this.members.map(member => `${member} is on team ${this.teamName}`);
  }
}

teams1.teamSummary();