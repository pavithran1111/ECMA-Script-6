var num = [{'one':1, car: 'ford'}, {'one':2, car: 'skoda'}, {one:3, car: 'audi'}]

var doubleNum = []

const s = num.map((a, n)=>
  a.car
);

console.log(s)

// ---------------------------------

var images = [
  { height: '34px', width: '39px' },
  { height: '54px', width: '19px' },
  { height: '83px', width: '75px' },
];

const heights = images.map((image)=> image.height);

console.log(heights)

// -----------------------------------

var trips = [
  { distance: 34, time: 10 },
  { distance: 90, time: 50 },
  { distance: 59, time: 25 }
];

var speeds;
speeds = trips.map((trip)=> trip.distance /trip.time);