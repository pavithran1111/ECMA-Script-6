var users = [
  {name: 'Ram'},
  {name: 'Laxman'},
  {name: 'Vignesh'}
]

const d = users.find((user)=> user.name === 'Ram');

console.log(d)

// -----------------------------------------------------

var posts = [
  {id: 1, title: 'New Post'},
  {id: 2, title: 'Old Post'}
];
var comment = { postId:2, content: 'Great Post'};

function postForComments(posts, comment){
  
  return posts.find((post)=>{
     return post.id === comment.postId
  })
}

var s = postForComments(posts, comment);
console.log(s)
// ------------------------------------------------------

var users = [
  { id: 1, admin: false },
  { id: 2, admin: false },
  { id: 3, admin: true }
];

var admin;

users.find(user=> user.admin)

// ---------------------------------------------------------

  return array.find(value => value.height === criteria.height )

