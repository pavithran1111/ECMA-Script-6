//Rest Operator
function addNumbers(...numbers){
  return numbers.reduce((total, number) => total + number) 
}

addNumbers(1,2,3)

// --------------------------------
//Spread Operator

const defaultColor = ['red', 'green', 'blue'];

const favouriteColor = ['orange', 'yellow'];

const fallColor = ['fire red', 'fall orange'];

['orangered', ...fallColor, ...defaultColor, ...favouriteColor ]



// -------------------------------------------------------
//both rest and spread

function validateShoppingList(...items){
  if(items.indexOf('milk') < 0){
   	return ['milk', ...items] 
  }
  return items;
}

validateShoppingList('oranges', 'bread')

// -----------------------------------------------------------

const mathLibrary = {
  
  calculateProduct(...rest) {
    //call multiple function instead
   return this.multiple(...rest);
 },

 multiple(a, b) {
    return a* b 
 }
};

mathLibrary.calculateProduct(2,3)