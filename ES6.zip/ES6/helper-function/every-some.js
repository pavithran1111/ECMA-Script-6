var computers = [
  {name: 'Apple', ram: 24},
  {name: 'Compaq', ram: 4},
  {name: 'Acer', ram: 32},
  ]

computers.every(computer =>
	 computer.ram > 16 
)


computers.some(computer =>
	 computer.ram > 16 
)

// --------------------------------

function Field(value){
  this.value = value
}

Field.prototype.validate = function(){
  return this.value.length > 0
}



const username = new Field('ddddd');
const password = new Field('mypassword');
const mobile = new Field('9089878');

const fields = [username, password, mobile]

const d = fields.every(field => field.validate());
d

// ------------------------------------

var users = [
  { id: 21, hasSubmitted: true },
  { id: 62, hasSubmitted: false },
  { id: 4, hasSubmitted: true }
];

var hasSubmitted;

hasSubmitted = users.every(user => user.hasSubmitted);