var products = [
  {name: 'cucumber', type: 'vegetable'},
  {name: 'banana', type: 'fruit'},
  {name: 'celery', type: 'vegetable'},
  {name: 'orange', type: 'fruit'} 
]

const a = products.filter((value)=>{
  return value.type === 'fruit'
});

console.log(a)

// ---------------------------------------------


var products = [
  {name: 'cucumber', type: 'vegetable', quantity: 0, price: 15},
  {name: 'banana', type: 'fruit', quantity: 30, price: 5},
  {name: 'celery', type: 'vegetable', quantity: 10, price: 1},
  {name: 'orange', type: 'fruit', quantity: 34, price: 2} 
]

const d = products.filter(product=>{
  return product.type === 'vegetable' && product.quantity > 0 && product.price < 10
});

console.log(d)

// ----------------------------------------------------


var numbers = [15, 25, 35, 45, 55, 65, 75, 85, 95];

var filteredNumbers;


filteredNumbers = numbers.filter((number)=>	number > 50)

console.log(filteredNumbers)

// --------------------------------------------------------

var users = [
 { id: 1, admin: true },  
 { id: 2, admin: false },
 { id: 3, admin: false },
 { id: 4, admin: false },
 { id: 5, admin: true },
];

var filteredUsers;


filteredUsers = users.filter(user=>	user.admin)

// --------------------------------------------------------