var nums = [ 10, 20, 30 ];


nums.reduce((a, num) => a+num, 0) 


// -------------------------------

var colors = [ {color: 'red'},{color: 'yellow'},{color: 'blue'} ];

colors.reduce((previous, color) => {
  
  previous.push(color.color);
  return previous;
}, []);

// -------------------------------------


function balancedParens(string){
  return !string.split('').reduce((previous, char) => {
	if(previous < 0 ) return previuos;
  	if(char === '(') return ++previous;
        if(char === ")") return --previous;
  	return previous;
  }, 0);
}

balancedParens("(()))");

// -----------------------------------------------

var trips = [{ distance: 34 }, { distance: 12 } , { distance: 1 }];

var totalDistance;

const t = trips.reduce((a, trip)=> a+trip.distance, 0);
console.log(t)

// -------------------------------------------------------------------------

var desks = [
  { type: 'sitting' },
  { type: 'standing' },
  { type: 'sitting' },
  { type: 'sitting' },
  { type: 'standing' }
];

var deskTypes = desks.reduce(function(a, desk) {
  
  if(desk.type === 'sitting') a.sitting++;
  if(desk.type === 'standing') a.standing++;

 return a;
    
}, { sitting: 0, standing: 0 });

console.log(deskTypes);

// --------------------------------------------------------------------

var numbers = [1, 1, 2, 3, 4, 4];

const n = numbers.reduce((a, number) => {

if(!a.includes(number)){
  a.push(number);
}
return a
}, []);

n