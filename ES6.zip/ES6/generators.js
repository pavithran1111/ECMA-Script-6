function *shopping(){
  //stuff on the sidewalk
  
  //walking down the side walk
  
  //go into the store with cash
  const stuffFromStore = yield 'cash';
  
  const cleanClothes = yield 'laundary';
  
  //walking back home
  return [stuffFromStore, cleanClothes];
  
}

//stuff in the store
const gen = shopping();

gen.next(); //leaving our home
//walked into the store
//walking up and down the aisles...
//purchase our stuff
gen.next('groceries'); //leaving the store with groceries

gen.next('clean clothes');

// -------------------------------------------------------------


function* colors(){
  
  yield 'red';
  const a =  yield 'blue';
   const s = yield 'green';
   
   return [a, s]
 }
 
 const myColor = []
 
 for (let color of colors()){
   myColor.push(color);
 }
 
 myColor

//  -----------------------------------------------------------------

const enggTeam = {
	size : 3,
  dept : 'Engg',
  lead : 'Jill',
  manager : 'Alex',
  engg : 'Laxman'
};

function* teamIterator(team) {
  yield team.lead;
  yield team.manager;
  yield team.engg;
}

let names = []

for(let name of teamIterator(enggTeam)){
 	names.push(name) 
}
names

// ------------------------------------------------------------------

const testingTeam4 = {
  dept : 'Tester',
  lead : "Kumar"
}
const enggTeam1 = {
  testingTeam4,
	size : 3,
  dept : 'Engg',
  lead : 'Jill',
  manager : 'Alex',
  engg : 'Laxman'
};

function* testingIterator(team) {
  yield team.lead;
  yield team.dept;
}

function* teamIterator(team) {
  yield team.lead;
  yield team.manager;
  yield team.engg;
  const testingGenerator = testingIterator(testingTeam);
  yield* testingGenerator;
}

let name1 = []

for(let name of teamIterator(enggTeam1)){
 	name1.push(name) 
}
name1

// ----------------------------------------------

const testingTeam1 = {
  dept : 'Tester',
  lead : "Kumar",
  [Symbol.iterator]: function* (){
  	yield this.dept;
    yield this.lead;
  }
}
const enggTeam2 = {
  testingTeam1,
	size : 3,
  dept : 'Engg',
  lead : 'Jill',
  manager : 'Alex',
  engg : 'Laxman'
};

function* testingIterator(team) {
  yield team.lead;
  yield team.dept;
}

function* teamIterator(team) {
  yield team.lead;
  yield team.manager;
  yield team.engg;
  yield* team.testingTeam1;
}

let name2 = []

for(let name of teamIterator(enggTeam2)){
 	name1.push(name) 
}
name2

// -------------------------------------------------

const testingTeam = {
  dept : 'Tester',
  lead : "Kumar",
  [Symbol.iterator]: function* (){
  	yield this.dept;
    yield this.lead;
  }
};

const enggTeam3 = {
  testingTeam,
	size : 3,
  dept : 'Engg',
  lead : 'Jill',
  manager : 'Alex',
  engg : 'Laxman',
  [Symbol.iterator]: function* (){
    yield this.lead;
  	yield this.dept;
		yield this.manager;
    yield this.engg;
    yield* this.testingTeam;
  }
};

let name3 = []

for(let name of enggTeam3){
 	name1.push(name) 
}
name4

// --------------------------------------------------------


