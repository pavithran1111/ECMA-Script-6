const fields = ['firstName', 'lastName', 'phoneNumber'];

const props = { fields };
