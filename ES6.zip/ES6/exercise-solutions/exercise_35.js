class Monster {
  constructor(options) {
    this.health = 100;
    this.name = options.name;
  }
}
