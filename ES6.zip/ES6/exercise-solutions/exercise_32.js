const profile = {
  title: 'Engineer',
  department: 'Engineering',
};

function isEngineer({ title, department }) {
  return title === 'Engineer' && department === 'Engineering';
}
