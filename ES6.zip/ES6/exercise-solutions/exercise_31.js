function unshift(array, ...rest) {
  return [...rest, ...array];
}
