function sum(a = 0, b = 0) {
  return a + b;
}
