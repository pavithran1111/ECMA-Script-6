const profile = {
  name: 'Alex',
  getName: function () {
    return this.name;
  },
};
